<div id="contentgen-app" class="contentgen-container">
    <div class="contentgen-loading">Loading ContentGen...</div>
</div> 