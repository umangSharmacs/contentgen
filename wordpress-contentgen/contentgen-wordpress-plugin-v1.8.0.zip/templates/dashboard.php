<div class="contentgen-dashboard">
    <div class="dashboard-header">
        <h1><?php echo esc_html($atts['title']); ?></h1>
        <div class="header-actions">
            <button class="selection-toggle-button" id="toggleView">
                Show Selected Tweets
                <span class="selection-badge" id="selectionCount" style="display: none;">0</span>
            </button>
        </div>
    </div>

    <!-- Loading State -->
    <div class="loading-spinner" id="loadingSpinner">
        <div class="spinner"></div>
        <p>Loading research data...</p>
    </div>

    <!-- Main Content Area -->
    <div class="dashboard-content" id="dashboardContent" style="display: none;">
        <!-- Research Cards Container -->
        <div class="research-cards-container" id="researchCardsContainer">
            <!-- Research cards will be loaded here via JavaScript -->
        </div>

        <!-- Tweet Cart -->
        <div class="tweet-cart" id="tweetCart" style="display: none;">
            <div class="cart-header">
                <h2>Selected Tweets</h2>
                <div class="cart-actions">
                    <button class="export-button" id="exportTweets">Export Selected</button>
                    <button class="clear-button" id="clearCart">Clear All</button>
                </div>
            </div>
            <div class="cart-items" id="cartItems">
                <!-- Cart items will be loaded here -->
            </div>
        </div>
    </div>

    <!-- Research Card Template -->
    <template id="researchCardTemplate">
        <div class="research-card" data-pmid="">
            <div class="card-header">
                <div class="header-left">
                    <div class="pmid-section">
                        <span class="pmid-label">PMID:</span>
                        <span class="pmid-value"></span>
                    </div>
                    <div class="doi-section" style="display: none;">
                        <span class="doi-label">DOI:</span>
                        <a href="" target="_blank" rel="noopener noreferrer" class="doi-link"></a>
                    </div>
                    <div class="cancer-type" style="display: none;">
                        <span class="cancer-label">Cancer:</span>
                        <span class="cancer-value"></span>
                    </div>
                </div>
                <div class="header-right">
                    <div class="date-section">
                        <span class="date-label">Date:</span>
                        <span class="date-value"></span>
                    </div>
                    <div class="journal-section">
                        <span class="journal-label">Journal:</span>
                        <span class="journal-value"></span>
                    </div>
                    <div class="score-section">
                        <span class="score-label">Score:</span>
                        <span class="score-value"></span>
                    </div>
                </div>
            </div>

            <div class="summary-section">
                <p class="summary-text"></p>
            </div>

            <div class="abstract-section" style="display: none;">
                <button class="abstract-toggle">Show Abstract</button>
                <div class="abstract-content" style="display: none;">
                    <p></p>
                </div>
            </div>

            <div class="tweet-section">
                <div class="tweet-header">
                    <span class="tweet-label">Tweet:</span>
                    <div class="tweet-actions">
                        <button class="copy-button" title="Copy to clipboard">
                            <span class="material-symbols-outlined">content_copy</span>
                        </button>
                        <button class="edit-button" title="Edit tweet">
                            <span class="material-symbols-outlined">edit</span>
                        </button>
                    </div>
                </div>
                <div class="tweet-content">
                    <textarea class="tweet-text" readonly></textarea>
                </div>
                <div class="tweet-edit-actions" style="display: none;">
                    <button class="save-edit">Save</button>
                    <button class="cancel-edit">Cancel</button>
                </div>
            </div>

            <div class="twitter-info" style="display: none;">
                <div class="hashtags-section">
                    <span class="hashtags-label">Hashtags:</span>
                    <span class="hashtags-value"></span>
                </div>
                <div class="accounts-section">
                    <span class="accounts-label">Accounts:</span>
                    <span class="accounts-value"></span>
                </div>
            </div>

            <div class="card-actions">
                <button class="accept-button">Accept</button>
                <button class="decline-button">Decline</button>
            </div>
        </div>
    </template>

    <!-- Cart Item Template -->
    <template id="cartItemTemplate">
        <div class="cart-item" data-pmid="">
            <div class="cart-item-header">
                <span class="cart-pmid"></span>
                <button class="remove-from-cart" title="Remove from cart">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>
            <div class="cart-tweet-content">
                <textarea class="cart-tweet-text" readonly></textarea>
            </div>
            <div class="cart-item-actions">
                <button class="edit-cart-tweet">Edit</button>
                <button class="save-cart-edit" style="display: none;">Save</button>
                <button class="cancel-cart-edit" style="display: none;">Cancel</button>
            </div>
        </div>
    </template>
</div> 